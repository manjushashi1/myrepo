# cloudrundemos
This repository is for Cloud Run Demos

In order to make the most out of this repository you can follow from the youtube videos 


- [Intorduction to Serverless with Google cloud Run](https://youtu.be/RYLDORG8aBw)

- [Google Cloud Run with Github Actions](https://youtu.be/eooi60Mks_0)

- [Cloud Run on GKE and Cloud Run using Terraform](https://youtu.be/I6spYL2v-4w)

- [Cloud Run - Continuous Deployment Setup](https://youtu.be/JzP2LDvdzzk)




gcloud config get-value project
gcloud builds submit --tag gcr.io/$/helloname



